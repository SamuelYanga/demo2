user_pref("startup.homepage_welcome_url", "data:text/html,PASS");
user_pref("marionette.defaultPrefs.enabled", false);
